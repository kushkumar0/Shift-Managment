package com.ahom.hrms.serviceimpl;

import java.util.List;

import com.ahom.hrms.dto.AddShiftDto;

public interface AddShiftService {

	AddShiftDto addShiftById(Integer id);

	void saveAddShift(AddShiftDto addShiftDto);

	List<AddShiftDto> getAllAddShift();

	AddShiftDto updateAddShift(AddShiftDto addShiftDto);

}
